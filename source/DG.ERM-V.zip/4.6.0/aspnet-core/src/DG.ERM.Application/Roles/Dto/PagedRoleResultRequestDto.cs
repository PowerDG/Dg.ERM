﻿using Abp.Application.Services.Dto;

namespace DG.ERM.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

