﻿using Abp.MultiTenancy;
using DG.ERM.Authorization.Users;

namespace DG.ERM.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
