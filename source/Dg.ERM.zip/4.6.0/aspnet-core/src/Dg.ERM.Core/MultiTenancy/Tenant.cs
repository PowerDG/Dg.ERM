﻿using Abp.MultiTenancy;
using Dg.ERM.Authorization.Users;

namespace Dg.ERM.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
