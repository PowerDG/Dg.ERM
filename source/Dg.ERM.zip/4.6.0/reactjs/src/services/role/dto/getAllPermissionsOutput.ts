export interface GetAllPermissionsOutput {
  name: string;
  displayName: string;
  description: string;
  id: number;
}
