export interface PagedUserResultRequestDto extends PagedFilterAndSortedRequest  {
    keyword: string
}
