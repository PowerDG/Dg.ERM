class RoleModel {
  name: string;
  displayName: string;
  description?: any;
  isStatic: boolean;
  id: number;
}

export default RoleModel;
